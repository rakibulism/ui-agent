# Build Roadmap
## UI Design Intelligence Platform
**Version:** 1.0  
**Model:** 6-phase open source build  

---

## Overview

```
PHASE 1          PHASE 2          PHASE 3          PHASE 4          PHASE 5          PHASE 6
Annotate         Embed +          Skill Pack        MCP Server       Fine-Tune        Community
30K Images       Vector DB        Generator         + API            Model            + Eval
─────────        ─────────        ──────────        ──────────       ──────────       ──────────
Weeks 1–4        Weeks 5–8        Weeks 9–11        Weeks 12–15      Weeks 16–24      Ongoing
```

---

## Phase 1 — Annotation Pipeline
**Duration:** Weeks 1–4  
**Goal:** Every image has structured metadata. Dataset ready to publish on HuggingFace.

### Deliverables
- Annotation pipeline script (`annotation-pipeline/annotate.py`)
- Annotation schema (finalized JSON structure)
- 30,000 annotation JSON files
- `master_index.json` — single file with all annotations
- `dataset_stats.json` — breakdown by type, style, quality score distribution
- HuggingFace dataset card (`README.md` + `dataset_card.md`)
- **Published: HuggingFace Dataset (public)**

### Tasks
| Task | Owner | Effort |
|---|---|---|
| Finalize annotation JSON schema | Rakibul | 1 day |
| Write and test annotation script (100 sample images) | Dev | 2 days |
| Run full pipeline (30K images, batched) | Dev | 2–3 days |
| QA: manual review of 200 random annotations | Rakibul | 2 days |
| Fix edge cases, re-annotate failures | Dev | 1 day |
| Write HuggingFace dataset card | Rakibul | 1 day |
| Publish dataset | Dev | 0.5 days |

### Success Criteria
- 95%+ of images successfully annotated (28,500/30,000 minimum)
- Annotation JSON validates against schema with no errors
- Dataset published and accessible on HuggingFace

---

## Phase 2 — Vector Database + Search API
**Duration:** Weeks 5–8  
**Goal:** Semantic search over the full dataset. Developers can query by text or image.

### Deliverables
- CLIP embedding pipeline (`embedding-pipeline/embed.py`)
- Qdrant vector store (local + Docker)
- FastAPI search server (`embedding-pipeline/search_api/`)
- Dockerfile + docker-compose for self-hosting
- API documentation (auto-generated via FastAPI)
- Hosted instance on Railway

### Tasks
| Task | Owner | Effort |
|---|---|---|
| Set up Qdrant locally, define collection schema | Dev | 1 day |
| Build CLIP embedding pipeline | Dev | 2 days |
| Run embedding pipeline on all 30K images | Dev | 1–2 days |
| Build FastAPI search endpoints | Dev | 3 days |
| Test search quality (manual queries) | Rakibul | 1 day |
| Add filters (ui_type, color_mode, quality) | Dev | 1 day |
| Write Dockerfile + docker-compose | Dev | 1 day |
| Deploy to Railway | Dev | 0.5 days |
| Write API docs | Dev | 1 day |

### Success Criteria
- Search returns relevant results for 90%+ of test queries
- Hosted API responds in under 500ms
- Docker image builds and runs cleanly
- API documented and publicly accessible

---

## Phase 3 — Skill Pack Generator
**Duration:** Weeks 9–11  
**Goal:** Structured, ready-to-use SKILL.md files for every major UI category. Published on GitHub.

### Deliverables
- Skill pack generator script (`skill-packs/generator.py`)
- 6 skill pack categories:
  - `saas-dashboard/SKILL.md`
  - `mobile-app/SKILL.md`
  - `landing-page/SKILL.md`
  - `admin-panel/SKILL.md`
  - `e-commerce/SKILL.md`
  - `ui-evaluation/SKILL.md`
- Each pack includes `examples.json` (top 20 curated examples)
- GitHub release v0.1.0 with all packs as ZIP download

### Tasks
| Task | Owner | Effort |
|---|---|---|
| Write skill generation prompt | Rakibul | 1 day |
| Build generator script (cluster → synthesize) | Dev | 2 days |
| Generate first drafts for all 6 categories | Dev | 1 day |
| Review and edit all 6 SKILL.md files for accuracy | Rakibul | 3 days |
| Select top 20 examples per category for examples.json | Rakibul | 1 day |
| Write README with usage instructions | Rakibul | 1 day |
| Publish GitHub release | Dev | 0.5 days |

### Success Criteria
- 6 skill packs published and downloadable
- Each SKILL.md includes: patterns, anti-patterns, component conventions, quality checklist
- Skills pass manual test: dropped into a Claude Project, they measurably improve UI design outputs

---

## Phase 4 — MCP Server + Full Platform Launch
**Duration:** Weeks 12–15  
**Goal:** Production MCP server. Full platform goes live. Community launch.

### Deliverables
- TypeScript MCP server (`mcp-server/`)
- 4 tools: `search_ui_patterns`, `get_component_examples`, `evaluate_ui_design`, `get_design_patterns`
- Hosted MCP server (Railway)
- npm package: `npx ui-design-intelligence-mcp`
- Full GitHub repository with all phases consolidated
- README with setup instructions for all 3 connection methods (hosted, Docker, npm)
- Demo video / GIF for README
- Launch post (ProductHunt, GitHub, HuggingFace)

### Tasks
| Task | Owner | Effort |
|---|---|---|
| Scaffold MCP server (TypeScript + SDK) | Dev | 2 days |
| Implement all 4 tool handlers | Dev | 3 days |
| Connect MCP server to Search API (Phase 2) | Dev | 1 day |
| Build `evaluate_ui_design` tool logic | Dev | 2 days |
| Test all tools end-to-end with Claude Desktop | Rakibul + Dev | 2 days |
| Write npm package wrapper | Dev | 1 day |
| Deploy hosted MCP to Railway | Dev | 0.5 days |
| Write README + setup guide | Rakibul | 1.5 days |
| Record demo GIF | Rakibul | 0.5 days |
| ProductHunt / GitHub / HuggingFace launch | Rakibul | 1 day |

### Success Criteria
- All 4 MCP tools callable from Claude Desktop with real results
- Hosted server live and stable
- npm package installable and working
- Repository publicly launched with 100+ GitHub stars in first week

---

## Phase 5 — Fine-Tuned Vision Model
**Duration:** Weeks 16–24  
**Goal:** Open vision model that deeply understands UI design. Published on HuggingFace.

### Deliverables
- Instruction-pair dataset (generated from annotations)
- Fine-tuned LLaVA-7B weights
- HuggingFace Model Card
- HuggingFace Inference API endpoint
- HuggingFace Space (interactive demo)
- Model evaluation results vs. base LLaVA-7B

### Tasks
| Task | Owner | Effort |
|---|---|---|
| Design instruction-pair template | Rakibul + Dev | 2 days |
| Generate instruction pairs from annotations (Claude API) | Dev | 3 days |
| Manual QA of instruction pairs (200 sample) | Rakibul | 2 days |
| Set up fine-tuning environment (Modal/Lambda) | Dev | 2 days |
| Run fine-tuning (LoRA on LLaVA-7B) | Dev | 3–5 days |
| Run eval against base model | Dev | 1 day |
| Iterate if needed | Dev | 3 days |
| Write HuggingFace model card | Rakibul | 1 day |
| Build HuggingFace demo Space | Dev | 2 days |
| Publish model | Dev | 0.5 days |

### Success Criteria
- Fine-tuned model scores 20%+ higher than base LLaVA-7B on UI component identification
- Model publicly accessible via HuggingFace Inference API
- Demo Space functional and shareable

---

## Phase 6 — Eval Benchmark + Community
**Duration:** Ongoing from Week 12  
**Goal:** A living benchmark. Community contributors extend the platform.

### Deliverables
- UI Design Eval Benchmark repository
- 5 test types: component identification, quality scoring, pattern recognition, improvement ranking, anti-pattern detection
- Public leaderboard (GitHub-hosted JSON)
- Contributing guide
- Issue templates
- Discord or GitHub Discussions community

### Benchmark Tasks
| Task | Owner | Effort |
|---|---|---|
| Design 5 test types and rubrics | Rakibul | 3 days |
| Select 500 benchmark images from dataset | Rakibul | 2 days |
| Write ground truth annotations for benchmark | Rakibul + Dev | 5 days |
| Build eval runner script | Dev | 3 days |
| Publish leaderboard format | Dev | 1 day |
| Submit initial Claude + GPT-4V results | Dev | 1 day |
| Write contribution guide | Rakibul | 1 day |

---

## Team Requirements

| Role | Phase | Responsibility |
|---|---|---|
| **ML/Backend Developer (Python)** | 1–5 | Annotation pipeline, embedding, FastAPI, fine-tuning |
| **Frontend/Node Developer** | 4 | MCP server (TypeScript), npm package |
| **Rakibul (Product + Design)** | All | Schema design, annotation QA, skill pack editing, launch |

Minimum viable team: 1 Python developer + Rakibul.  
Optional: 1 Node.js developer for MCP server (or same Python dev with TypeScript knowledge).

---

## Budget Summary

| Item | Type | Cost |
|---|---|---|
| Claude API — annotation (30K images, Batch API) | One-time | $50–150 |
| Claude API — skill pack generation | One-time | $5–15 |
| Claude API — instruction pairs (fine-tuning dataset) | One-time | $30–80 |
| GPU rental for fine-tuning (Lambda Labs / Modal) | One-time | $200–500 |
| Railway hosting (API + MCP server) | Monthly | $5–15 |
| Qdrant Cloud (free tier 1M vectors) | Monthly | $0 |
| HuggingFace (public repos) | Monthly | $0 |
| GitHub (public) | Monthly | $0 |
| **Total one-time** | | **$285–745** |
| **Total monthly (ongoing)** | | **$5–15** |

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Annotation quality inconsistent | Medium | High | QA 200 samples per batch; re-run failures with refined prompt |
| CLIP search quality poor for complex queries | Medium | Medium | Add hybrid search (text embeddings + CLIP); human-curated fallback |
| Fine-tuning overfits / underperforms | Medium | Medium | Start with LoRA; use small dataset first; iterate |
| MCP ecosystem changes break server | Low | Medium | Pin SDK versions; monitor MCP spec updates |
| Image copyright issues | Low | High | Ensure all 30K images are owned/licensed for open distribution before publishing |

---

## Launch Checklist

Before public announcement:

- [ ] 28,500+ images annotated and validated
- [ ] Dataset live on HuggingFace with proper card and license
- [ ] Search API live and responsive
- [ ] All 6 skill packs downloadable from GitHub
- [ ] MCP server installable via `npx` and working with Claude Desktop
- [ ] README complete with demo GIF
- [ ] License files present (MIT, CC BY 4.0)
- [ ] Copyright verification done for all 30K images
- [ ] Contributing guide written
- [ ] First 3 issues pre-written as "good first issues" for community
