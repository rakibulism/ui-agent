# Technical Architecture Document
## UI Design Intelligence Platform
**Version:** 1.0  
**Type:** System Design + Stack Reference  

---

## 1. System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        30K RAW UI IMAGES                         │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                  PHASE 1: ANNOTATION PIPELINE                    │
│   Claude Vision API → JSON Metadata per image → Master Index    │
└─────────────────────────┬───────────────────────────────────────┘
                          │
            ┌─────────────┴─────────────┐
            ▼                           ▼
┌───────────────────────┐   ┌───────────────────────────────────┐
│  PHASE 2: VECTOR DB   │   │   PHASE 3: SKILL PACK GENERATOR   │
│  CLIP Embeddings →    │   │   Metadata → Structured .md files │
│  Qdrant Vector Store  │   │   Published to GitHub releases     │
└───────────┬───────────┘   └───────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│                   PHASE 4: MCP SERVER + API                      │
│        FastAPI Search Endpoints + TypeScript MCP Server          │
│   Tools: search / evaluate / component_examples / patterns       │
└─────────────────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│                  PHASE 5: FINE-TUNED MODEL                       │
│   Instruction pairs from annotations → Fine-tune LLaVA-7B       │
│   Host on HuggingFace Hub                                        │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Phase 1 — Auto-Annotation Pipeline

### Goal
Transform 30K raw images into a structured, richly annotated dataset.

### How It Works
1. Images are processed in batches through the Claude Vision API
2. Each image gets a structured JSON annotation
3. All annotations are merged into a master index file

### Annotation Prompt (per image)
```
You are a senior UI/UX design analyst. Analyze this UI design image and return ONLY a valid JSON object with no markdown.

{
  "ui_type": "saas_dashboard | mobile_app | landing_page | website | admin_panel | e_commerce | other",
  "components": ["list of UI components visible: sidebar, navbar, card, table, chart, modal, form, button, input, tab, badge, avatar, tooltip, etc."],
  "layout_pattern": "split_layout | full_width | grid | single_column | sidebar_main | centered | asymmetric",
  "color_mode": "light | dark | system",
  "dominant_colors": ["#hex1", "#hex2", "#hex3"],
  "design_style": ["minimal", "dense", "editorial", "glassmorphism", "flat", "neumorphic", "brutalist", "material", "ios_native", "android_native"],
  "design_patterns": ["empty_state", "loading_state", "onboarding", "settings", "data_table", "kanban", "timeline", "wizard", "dashboard", "analytics", "profile", "checkout", "auth"],
  "quality_score": {
    "overall": 7,
    "visual_hierarchy": 8,
    "spacing_consistency": 6,
    "typography": 7,
    "color_harmony": 8,
    "component_consistency": 7
  },
  "keywords": ["list of 5-10 descriptive keywords for semantic search"],
  "brief_description": "One sentence describing what this UI screen does and its visual style."
}
```

### Implementation

```python
# annotation_pipeline.py
import anthropic
import json
import base64
import os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

def annotate_image(image_path: str) -> dict:
    with open(image_path, "rb") as f:
        image_data = base64.standard_b64encode(f.read()).decode("utf-8")

    ext = Path(image_path).suffix.lower()
    media_type_map = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}
    media_type = media_type_map.get(ext, "image/jpeg")

    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": image_data}},
                {"type": "text", "text": ANNOTATION_PROMPT}
            ]
        }]
    )

    raw = response.content[0].text.strip()
    return json.loads(raw)

def run_pipeline(images_dir: str, output_dir: str, workers: int = 5):
    images = list(Path(images_dir).glob("**/*.{jpg,jpeg,png,webp}"))
    results = {}

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(annotate_image, str(img)): img for img in images}
        for future, img_path in futures.items():
            try:
                annotation = future.result()
                results[str(img_path)] = annotation
                print(f"✓ {img_path.name}")
            except Exception as e:
                print(f"✗ {img_path.name}: {e}")

    # Save master index
    with open(f"{output_dir}/master_index.json", "w") as f:
        json.dump(results, f, indent=2)

    print(f"\nAnnotated {len(results)}/{len(images)} images")
```

### Cost Estimate
- Model: `claude-opus-4-5` or `claude-sonnet-4-5` (sonnet preferred for cost)
- Tokens per image: ~500 input + ~300 output = ~800 tokens
- 30,000 images × 800 tokens = ~24M tokens
- Cost at Sonnet pricing (~$3/M input, $15/M output): ~$100–150 total
- With Claude Batch API (50% discount): ~$50–75

### Output Format
```
/dataset
  /images
    image_001.jpg
    image_002.png
    ...
  /annotations
    image_001.json
    image_002.json
    ...
  master_index.json       ← all annotations in one file
  dataset_stats.json      ← summary statistics
```

---

## 3. Phase 2 — Vector Embedding + Search

### Goal
Make the dataset semantically searchable — both by text and by visual similarity.

### Embedding Strategy (Hybrid)

**Text embeddings:** From the annotation JSON (description + keywords + components)  
**Image embeddings:** From the raw images using a vision model (CLIP)

Both are stored in Qdrant. Queries can hit either or both embedding spaces.

### Tech Stack
- **Embedding model:** `openai/clip-vit-large-patch14` (free, runs locally)
- **Vector DB:** Qdrant (open source, Docker, self-hostable)
- **Search API:** FastAPI (Python)

### Embedding Pipeline

```python
# embed_pipeline.py
from transformers import CLIPProcessor, CLIPModel
import torch
from PIL import Image
import qdrant_client
from qdrant_client.models import Distance, VectorParams, PointStruct

# Load CLIP
model = CLIPModel.from_pretrained("openai/clip-vit-large-patch14")
processor = CLIPProcessor.from_pretrained("openai/clip-vit-large-patch14")

# Connect to Qdrant
client = qdrant_client.QdrantClient(host="localhost", port=6333)

# Create collection
client.create_collection(
    collection_name="ui_designs",
    vectors_config={
        "image": VectorParams(size=768, distance=Distance.COSINE),
        "text": VectorParams(size=768, distance=Distance.COSINE),
    }
)

def embed_image(image_path: str) -> list[float]:
    image = Image.open(image_path)
    inputs = processor(images=image, return_tensors="pt")
    with torch.no_grad():
        features = model.get_image_features(**inputs)
    return features[0].numpy().tolist()

def embed_text(text: str) -> list[float]:
    inputs = processor(text=[text], return_tensors="pt", padding=True)
    with torch.no_grad():
        features = model.get_text_features(**inputs)
    return features[0].numpy().tolist()

def index_image(image_id: str, image_path: str, annotation: dict):
    img_vec = embed_image(image_path)
    text_content = f"{annotation['brief_description']} {' '.join(annotation['keywords'])} {' '.join(annotation['components'])}"
    txt_vec = embed_text(text_content)

    client.upsert(
        collection_name="ui_designs",
        points=[PointStruct(
            id=hash(image_id) % (2**63),
            vector={"image": img_vec, "text": txt_vec},
            payload={
                "image_path": image_path,
                "ui_type": annotation["ui_type"],
                "components": annotation["components"],
                "design_style": annotation["design_style"],
                "quality_score": annotation["quality_score"]["overall"],
                "color_mode": annotation["color_mode"],
                "brief_description": annotation["brief_description"],
                "keywords": annotation["keywords"],
            }
        )]
    )
```

### Search API (FastAPI)

```python
# api/search.py
from fastapi import FastAPI, Query
from pydantic import BaseModel

app = FastAPI(title="UI Design Search API")

@app.get("/search")
def search(
    q: str = Query(..., description="Natural language search query"),
    ui_type: str = None,
    color_mode: str = None,
    min_quality: int = 0,
    limit: int = 12
):
    query_vec = embed_text(q)
    results = qdrant_client.search(
        collection_name="ui_designs",
        query_vector=("text", query_vec),
        query_filter=build_filter(ui_type, color_mode, min_quality),
        limit=limit,
        with_payload=True
    )
    return {"results": [r.payload for r in results]}

@app.post("/similar")
def find_similar(image_url: str, limit: int = 12):
    # Download image, embed, search
    ...
```

---

## 4. Phase 3 — Skill Pack Generator

### Goal
Auto-generate structured `.md` skill files from the annotated dataset — categorized by UI type and design domain. These are ready to drop into Claude Projects, agent system prompts, or any context window.

### Generation Logic
1. Group all annotations by `ui_type`
2. For each category, cluster by patterns and components
3. Use Claude to synthesize knowledge from clusters → structured SKILL.md

```python
# skill_generator.py

SKILL_GENERATION_PROMPT = """
You are a senior product designer with 15+ years of experience.
Based on these {count} real UI design annotations from the '{category}' category,
write a comprehensive SKILL.md file that captures:

1. Common design patterns in this category
2. Standard component conventions and usage
3. Layout and spacing conventions
4. Color and typography patterns
5. Quality indicators (what separates good from bad)
6. Anti-patterns to avoid
7. Checklist for AI agents evaluating designs in this category

Annotations:
{annotations_sample}

Return a well-structured markdown skill file only.
"""
```

### Skill Pack Structure
```
/skill-packs
  /saas-dashboard/
    SKILL.md
    examples.json      ← top 20 examples by quality score
  /mobile-app/
    SKILL.md
    examples.json
  /landing-page/
    SKILL.md
  /admin-panel/
    SKILL.md
  /e-commerce/
    SKILL.md
  /ui-evaluation/
    SKILL.md           ← general UI quality evaluation skill
  README.md
  CHANGELOG.md
```

---

## 5. Phase 4 — MCP Server

### Goal
Expose the platform as a first-class MCP server so any agent can connect and use UI design intelligence as callable tools.

### Tech Stack
- Language: TypeScript (Node.js) — standard for MCP servers
- MCP SDK: `@modelcontextprotocol/sdk`
- Calls: Internal Search API (Phase 2)

### MCP Server Architecture

```typescript
// src/index.ts
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

const server = new Server(
  { name: "ui-design-intelligence", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

// Tool definitions
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "search_ui_patterns",
      description: "Search for real UI design examples by natural language query, type, or style",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string" },
          ui_type: { type: "string", enum: ["saas_dashboard", "mobile_app", "landing_page", "admin_panel", "e_commerce"] },
          color_mode: { type: "string", enum: ["light", "dark"] },
          min_quality: { type: "number", minimum: 0, maximum: 10 },
          limit: { type: "number", default: 6 }
        },
        required: ["query"]
      }
    },
    {
      name: "get_component_examples",
      description: "Get real UI examples showing a specific component (sidebar, modal, data table, etc.)",
      inputSchema: {
        type: "object",
        properties: {
          component: { type: "string" },
          style: { type: "string" }
        },
        required: ["component"]
      }
    },
    {
      name: "evaluate_ui_design",
      description: "Evaluate a UI design description against quality criteria from 30K real design examples",
      inputSchema: {
        type: "object",
        properties: {
          description: { type: "string" },
          ui_type: { type: "string" }
        },
        required: ["description"]
      }
    },
    {
      name: "get_design_patterns",
      description: "Get documented design patterns for a specific screen or scenario",
      inputSchema: {
        type: "object",
        properties: {
          scenario: { type: "string" }
        },
        required: ["scenario"]
      }
    }
  ]
}));

// Tool handlers
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  
  switch (name) {
    case "search_ui_patterns":
      return await searchUIPatterns(args);
    case "get_component_examples":
      return await getComponentExamples(args);
    case "evaluate_ui_design":
      return await evaluateUIDesign(args);
    case "get_design_patterns":
      return await getDesignPatterns(args);
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
});

const transport = new StdioServerTransport();
await server.connect(transport);
```

### MCP Server Deployment Options

| Method | How |
|---|---|
| **Hosted (recommended)** | Deploy to Railway/Fly.io. Users connect via URL in their MCP client config |
| **Self-hosted (Docker)** | `docker run -p 3000:3000 ui-design-intelligence` |
| **Local (npm)** | `npx ui-design-intelligence-mcp` |

### Claude Desktop Config (for end users)
```json
{
  "mcpServers": {
    "ui-design-intelligence": {
      "command": "npx",
      "args": ["ui-design-intelligence-mcp"]
    }
  }
}
```

---

## 6. Phase 5 — Fine-Tuned Vision Model

### Goal
A specialized vision-language model that deeply understands UI design — trained on the annotated dataset.

### Training Data Format (instruction pairs)
```json
{
  "image": "image_001.jpg",
  "instruction": "Describe this UI design in detail, identifying all components, layout patterns, and design quality.",
  "output": "This is a dark SaaS analytics dashboard using a sidebar-main layout. Components include: left navigation sidebar with icon labels, top header bar with search and avatar, 4-column metric cards, a line chart panel, and a data table with pagination. The quality score is 8/10 — strong visual hierarchy, consistent 8px spacing grid, and a cohesive dark color palette..."
}
```

### Model Choices
| Option | Pros | Cons |
|---|---|---|
| **LLaVA-7B fine-tune** | Free, open weights, self-hostable | Requires GPU, more infra |
| **OpenAI GPT-4V fine-tune** | Easier pipeline, hosted | Costs more, proprietary |
| **Idefics2 (HuggingFace)** | Open, smaller, fast | Less capable |

**Recommended: LLaVA-7B** for open source alignment. Train on A100 via Modal or Lambda Labs (~$200–500 one-time).

### HuggingFace Publication
```
username/ui-design-llava-7b
  - model weights
  - model card with eval results
  - inference API enabled
  - demo Space on HuggingFace
```

---

## 7. Full Tech Stack Summary

| Layer | Technology | Why |
|---|---|---|
| Annotation | Python + Anthropic Claude API | Best vision understanding, structured output |
| Image Embedding | CLIP (openai/clip-vit-large-patch14) | Best image-text alignment, free, local |
| Vector Database | Qdrant | Open source, Docker, self-hostable, fast |
| Search API | FastAPI (Python) | Fast, lightweight, great DX |
| MCP Server | TypeScript + MCP SDK | Standard for MCP ecosystem |
| Dataset Hosting | HuggingFace Hub | Standard for open datasets |
| Model Hosting | HuggingFace Model Hub | Standard for open models |
| Code Hosting | GitHub | Open source standard |
| API Hosting | Railway or Fly.io | Simple, affordable, Docker-native |
| Fine-tuning Infra | Modal or Lambda Labs | On-demand GPU, cost-efficient |

---

## 8. Repository Structure

```
/ui-design-intelligence
  README.md
  /annotation-pipeline      ← Phase 1
    annotate.py
    requirements.txt
    prompts/
  /embedding-pipeline       ← Phase 2
    embed.py
    search_api/
      main.py
      Dockerfile
      docker-compose.yml
  /skill-packs              ← Phase 3
    /saas-dashboard/
    /mobile-app/
    /landing-page/
    generator.py
  /mcp-server               ← Phase 4
    package.json
    src/
      index.ts
      tools/
    Dockerfile
  /fine-tuning              ← Phase 5
    prepare_dataset.py
    train.py
    evaluate.py
  /eval-benchmark           ← Eval
    benchmark/
    scripts/
    leaderboard.json
  /dataset                  ← Published to HuggingFace separately
    README.md
    dataset_card.md
```

---

## 9. Infrastructure & Costs

| Service | Monthly Cost | Notes |
|---|---|---|
| Qdrant Cloud (free tier) | $0 | Up to 1M vectors |
| Railway API hosting | $5–10 | FastAPI + MCP server |
| HuggingFace Hub | $0 | Free for public repos |
| GitHub | $0 | Public repo |
| Fine-tuning (one-time) | $200–500 | GPU rental, Lambda Labs |
| Annotation (one-time) | $50–150 | Claude Batch API |
| **Total recurring** | **~$5–10/mo** | |
| **Total one-time** | **~$300–650** | |
